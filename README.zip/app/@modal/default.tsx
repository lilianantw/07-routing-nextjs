export default function ModalDefault() {
  return null; // Или можно вернуть что-то вроде пустого div
}
