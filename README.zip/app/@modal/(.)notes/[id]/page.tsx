import NotePreview from "./NotePreview";

interface NoteModalPageProps {
  params: { id: string };
}

export default function NoteModalPage({ params }: NoteModalPageProps) {
  return <NotePreview id={params.id} />;
}
