import { fetchNotes } from "@/lib/api";
import NotesClient from "./Notes.client";

interface NotesPageProps {
  params: {
    slug?: string[];
  };
}

export default async function NotesPage({ params }: NotesPageProps) {
  const tag = params.slug ? params.slug[0] : "All";

  // Если All, то пустой search, иначе фильтр по категории
  const search = tag === "All" ? "" : tag;

  const { notes, totalPages } = await fetchNotes({ page: 1, search });

  return (
    <NotesClient
      initialNotes={notes}
      initialTotalPages={totalPages}
      initialTag={tag}
    />
  );
}
