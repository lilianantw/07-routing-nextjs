import SidebarNotes from "./SidebarNotes";

export default function SidebarPage() {
  return <SidebarNotes />;
}
