(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c924e0f8._.js",
  "static/chunks/_06c6b91c._.js",
  "static/chunks/_4ea50008._.css"
],
    source: "dynamic"
});
