(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1545f4b4._.css",
  "static/chunks/node_modules_cc4c6a3a._.js",
  "static/chunks/components_TanStackProvider_TanStackProvider_tsx_720f3904._.js"
],
    source: "dynamic"
});
