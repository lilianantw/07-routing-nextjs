(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_98c11f6f._.js",
  "static/chunks/app_not-found_module_32681418.css"
],
    source: "dynamic"
});
