(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fb042aaa._.js",
  "static/chunks/_fd5d9b0c._.js",
  "static/chunks/_230ef6fd._.css"
],
    source: "dynamic"
});
